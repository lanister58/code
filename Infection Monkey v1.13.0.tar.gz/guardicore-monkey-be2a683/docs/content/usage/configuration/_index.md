---
title: "Configuration"
date: 2020-06-07T19:08:51+03:00
draft: false
chapter: true
weight: 3
pre: "<i class='fas fa-sliders-h'></i> "
---

# Configure the Infection Monkey

The Infection Monkey is highly configurable. Nearly every part of it can be modified to turn it into a fast-acting worm or a port scanning and system information collecting machine.

{{% notice warning %}}
This section of the documentation is incomplete and under active construction.
{{% /notice %}}

See these documentation pages for information on each configuration value:

{{% children description=true style="p"%}}
