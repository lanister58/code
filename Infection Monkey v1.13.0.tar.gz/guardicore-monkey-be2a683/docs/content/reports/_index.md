+++
title = "Reports"
date = 2020-06-24T21:16:03+03:00
weight = 40
chapter = true
pre = "<i class='fas fa-scroll'></i> "
+++

# Infection Monkey's Reports

The Infection Monkey offers three reports:

{{% children description=true style="p"%}}
