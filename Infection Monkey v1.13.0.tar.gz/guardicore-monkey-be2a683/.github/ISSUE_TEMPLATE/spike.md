---
name: "⌛Spike"
about: Create a spike to investigate a cool idea.
title: ''
labels: Spike
assignees: ''

---

# Spike

<!--
    A spike is a small chunk of work with the objective of gathering information.
    Fill in the details below to set the parameters and expectations for the spike.
-->

## Objective
_A description of this spike's objective._

## Scope
_Add an explanation of how this spike is bounded (e.g. time-boxed or a checklist of tasks or questions that must be answered)._

## Output
_Add a description or list of expected outputs that result from successful completion of this spike. Some examples of outputs are more GitHb issues (e.g. bugs), a trade study, or a report detailing what was learned during the spike._
