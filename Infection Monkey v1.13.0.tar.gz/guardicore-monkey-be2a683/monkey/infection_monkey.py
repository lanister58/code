from infection_monkey.main import main

if "__main__" == __name__:
    main()
