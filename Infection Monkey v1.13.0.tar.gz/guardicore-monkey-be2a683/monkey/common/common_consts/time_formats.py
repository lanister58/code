# Default time format used in the application, follows European standard.
# Example: 1992-03-04 10:32:05
DEFAULT_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
