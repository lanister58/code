T1216_PBA_FILE_DOWNLOAD_PATH = "/api/t1216-pba/download"
