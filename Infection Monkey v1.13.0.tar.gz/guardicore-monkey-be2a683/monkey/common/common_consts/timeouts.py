SHORT_REQUEST_TIMEOUT = 2.5  # Seconds. Use where we expect timeout.
MEDIUM_REQUEST_TIMEOUT = 5  # Seconds. Use where we don't expect timeout.
LONG_REQUEST_TIMEOUT = 15  # Seconds. Use where we don't expect timeout and operate heavy data.
