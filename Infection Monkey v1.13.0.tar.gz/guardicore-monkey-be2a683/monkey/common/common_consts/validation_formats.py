# Defined in UI on ValidationFormats.js
IP_RANGE = "ip-range"
IP = "ip"
VALID_RANSOMWARE_TARGET_PATH_LINUX = "valid-ransomware-target-path-linux"
VALID_RANSOMWARE_TARGET_PATH_WINDOWS = "valid-ransomware-target-path-windows"
