from pathlib import Path

README_SRC = Path(__file__).parent / "ransomware_readme.txt"
README_FILE_NAME = "README.txt"
README_SHA256_HASH = "a5608df1d9dbdbb489838f9aaa33b06b6cd8702799ff843b4b1704519541e674"
