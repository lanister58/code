 ██████████                        ██  █████       ███████████                        ███
░░███░░░░███                      ███ ░░███       ░░███░░░░░███                      ░░░
 ░███   ░░███  ██████  ████████  ░░░  ███████      ░███    ░███  ██████   ████████   ████   ██████
 ░███    ░███ ███░░███░░███░░███     ░░░███░       ░██████████  ░░░░░███ ░░███░░███ ░░███  ███░░███
 ░███    ░███░███ ░███ ░███ ░███       ░███        ░███░░░░░░    ███████  ░███ ░███  ░███ ░███ ░░░
 ░███    ███ ░███ ░███ ░███ ░███       ░███ ███    ░███         ███░░███  ░███ ░███  ░███ ░███  ███
 ██████████  ░░██████  ████ █████      ░░█████     █████       ░░████████ ████ █████ █████░░██████
░░░░░░░░░░    ░░░░░░  ░░░░ ░░░░░        ░░░░░     ░░░░░         ░░░░░░░░ ░░░░ ░░░░░ ░░░░░  ░░░░░░

                                               -yddy-
                                   ``          yN::Ny          ``
                                 `ymdmo        .hNNh.  .     omdmy`
                                 :Ny:dm.      .`-NN-  -m    .md:yN:
                                  :sdNN:     :m:+NN+:ymy -` :NNds:
                                     +Nmo-/ohNNmNNNNNNNdms-+mN+
                         ```          dNNNNNNNNNNNNNNNNNNNNNNd          ```
                       `ymhms      `+dNNNNNNNNNNNNNNNNNNNNNNNNd+`      smhmy`
                       :Ny:dNh-   +mNNNNNNNNNNNNNNNNNNNNNNNNNNNNm+   -hNd:yN:
                        -ossydNmhmNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmhmNdysso-
                              .dNNNNNNNNmhyyhdNNNNNNNNdhyyhmNNNNNNNNh.
                          ./ooodNNNNNms-  ..` `/hNNh/` `..  -omNNNNNdooo/.
                        /dNNNNNNNNNNd. :hNNNNms. ++ .smNNNmy: .dNNNNNNNNNNd/
                       yNNmo:-mNNNNm. +NNmyodNNm.  .mNNdoymNN+ .mNNNNm-:omNNy
                      /NNN-  -NNNNNm  hNNy  .NNN/  /NNN.  yNNh  mNNNNN-  -NNN/
                      /NNN.  :NNNNNN: :mNNdhmNNh`  `hNNmhdNNm: :NNNNNN:  .NNN/
                      `dNNd/..NNNNNNm/ .ohmmdy/ ```` /ydmmho. /mNNNNNN.`/dNNd`
                       `omNNNmNNNNNNNNh+-`     :h::h:     `-+hNNNNNNNNmNNNmo`
                         `:oyyymNNNNNNNNNmh+`          `+hmNNNNNNNNNmyyyo:`
                              `hNNNNNNNNNs`/yys+/::/+syy/`yNNNNNNNNNh`
                        ./+++ymNmNNNNNNNNd    `-://:-`    dNNNNNNNNmNmy+++/.
                       -mh+dNd/` `sNNNNNNNo              oNNNNNNNs` `/dNd+hm:
                       .ddsmh`     -ymNNNNNh-          -hNNNNNms-     `hmsdd.
                         --.         `dNNNNNNds/:--:/sdNNNNNNd`         .--
                                       :NNs/oydmNNNNNNNNmdyo/sNm:
                                  .+hNN/      `.sNNs.`      /NNy+.
                                 :my/dm.        -NN-        .md/ym-
                                 .ddymy        `yNNy`       `ymydd.
                                   .-.         yN//Ny         .-.
                                               :dmmd:

This is NOT a real ransomware attack.

Infection Monkey is an open-source breach and attack simulation (BAS) platform. The files in this
directory have been manipulated as part of a ransomware simulation. If you've discovered this file
and are unsure about how to proceed, please contact your administrator.

For more information about Infection Monkey, see https://www.guardicore.com/infectionmonkey.

For more information about Infection Monkey's ransomware simulation, see
https://www.guardicore.com/infectionmonkey/docs/reference/ransomware.
