"""
This package holds all the dynamic (plugin) collectors
"""
