def get_windows_commands_to_discover_accounts():
    return "powershell Get-LocalUser"
