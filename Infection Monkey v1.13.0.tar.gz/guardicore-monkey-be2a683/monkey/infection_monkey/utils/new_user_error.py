class NewUserError(Exception):
    pass
