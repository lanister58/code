"""
This package contains resources used by blackbox tests
to analyze test results, download logs and so on.
"""
