from monkey_island.cc.models.attack.mitigation import Mitigation
