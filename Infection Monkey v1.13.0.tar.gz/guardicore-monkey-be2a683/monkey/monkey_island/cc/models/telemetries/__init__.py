from .telemetry_dal import save_telemetry, get_telemetry_by_query
