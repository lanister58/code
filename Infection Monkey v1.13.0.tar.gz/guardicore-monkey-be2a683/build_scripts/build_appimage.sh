#!/bin/bash

./build_package.sh --package appimage $@
