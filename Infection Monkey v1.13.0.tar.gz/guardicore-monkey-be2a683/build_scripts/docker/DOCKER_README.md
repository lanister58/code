# Infection Monkey

For instructions on setting up the Infection Monkey Docker container, see
[https://www.guardicore.com/infectionmonkey/docs/setup/docker/](https://www.guardicore.com/infectionmonkey/docs/setup/docker/).
